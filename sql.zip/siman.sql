-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 18-06-2024 a las 07:17:39
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `siman`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_cliente`
--

CREATE TABLE `tbl_cliente` (
  `id_cliente` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apellido` varchar(50) DEFAULT NULL,
  `direccion` varchar(50) DEFAULT NULL,
  `telefono` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tbl_cliente`
--

INSERT INTO `tbl_cliente` (`id_cliente`, `nombre`, `apellido`, `direccion`, `telefono`) VALUES
(1, 'Kevin', 'Villalta', 'd', '0000-0001'),
(2, 'Ivan', 'Molina', 'Pacifigod', '0000-0002'),
(3, 'Cistian', 'Rubio', 'El gavilan', '0000-0003'),
(4, 'Kevin', 'Granada', 'La unionzz', '0000-0004'),
(5, 'Fatima', 'Cruz', 'ni idea', '0000-0005'),
(6, 'Manuel', 'Melendez', 'morazangod', '7934-7400'),
(7, '{txt_Nombre.Text}', '{txt_Apellido.Text}', '{txt_Direccion}', '{mtxt_Telefono}'),
(8, '{txt_Nombre.Text}', '{txt_Apellido.Text}', '{txt_Direccion}', '{mtxt_Telefono}'),
(9, 'tote', 'molina', 'System.Windows.Forms.TextBox, Text: SM', 'System.Windows.Forms.MaskedTextBox, Text: 0000-000'),
(10, 'tote', 'molina', 'System.Windows.Forms.TextBox, Text: SM', 'System.Windows.Forms.MaskedTextBox, Text: 0000-000'),
(11, '1', '1', '1', '1'),
(12, 'carlos', 'melendez', 'SC', '79347465'),
(13, 'carlos', 'melendez', 'SC', '79347465'),
(14, 'carlos', 'melendez', 'SC', '79347465'),
(15, 'carlos', 'melendez', 'SC', '79347465'),
(16, 'carlos', 'melendez', 'SC', '79347465'),
(17, 'carlos', 'melendez', 'SC', '79347465'),
(18, 'carlos', 'melendez', 'SC', '79347465'),
(19, 'carlos', 'melendez', 'SC', '79347465'),
(20, 'carlos', 'melendez', 'SC', '79347465'),
(21, 'carlos', 'melendez', 'SC', '79347465'),
(22, 'carlos', 'melendez', 'SC', '79347465'),
(23, 'carlos', 'melendez', 'SC', '79347465'),
(24, 'carlos', 'melendez', 'SC', '79347465'),
(25, 'carlos', 'melendez', 'SC', '79347465'),
(26, 'ca', 'ca', 'ca', '3'),
(27, 'r', 'r', 'r', '4'),
(28, 'd', 'd', 'd', 'd'),
(29, 'e', 'e', 'e', '4'),
(30, 'e', 'e', 'e', '4'),
(31, '1', '2', '3', '4'),
(32, '1', '2', '3', '4'),
(33, 'futuro', 'ingeniero', 'espazzz', '3'),
(34, '3', '3', '3', '3'),
(35, 'fatima', 'molina', 'san', '3'),
(36, '1', '2', '3', '4'),
(37, '1', '2', '3', '4'),
(38, 'Ivan', 'Molina', 'Pacifigod', '0000-0002');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_productos`
--

CREATE TABLE `tbl_productos` (
  `id_productos` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tbl_productos`
--

INSERT INTO `tbl_productos` (`id_productos`, `nombre`, `cantidad`, `precio`) VALUES
(1, 'Teclado', 38, 34.40),
(2, 'Monitor', 88, 23.30),
(3, 'Maus', 22, 3.00),
(4, 'Telefono', 97, 300.00),
(5, 'Locion', 300, 43.00),
(6, 'Nike Cortes', 20, 40.00),
(7, 'HOT WEELS', 200, 2.00),
(8, 'Camisa', 300, 10.00),
(9, 'Pantalon', 300, 49.00),
(10, 'Reloj', 30, 50.00),
(11, 'Mesa', 20, 40.00),
(12, 'Zapatos', 300, 43.00),
(13, 'Computadora', 300, 900.00),
(14, 'Cama', 3, 400.00),
(15, 'Guitarra', 30, 60.00),
(16, 'Flauta', 300, 7.00),
(17, 'Pelota', 30, 32.00),
(18, 'Wisqui', 40, 43.00),
(19, 'Cuaderno', 500, 3.00),
(20, 'Chocolate', 30, 4.00),
(21, 'Jabo', 100, 2.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_usuario`
--

CREATE TABLE `tbl_usuario` (
  `id_usuario` int(11) NOT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `contraseña` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tbl_usuario`
--

INSERT INTO `tbl_usuario` (`id_usuario`, `usuario`, `contraseña`) VALUES
(18, 'paiz', '1234'),
(19, 'oldtote4', 'dejandofede');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `tbl_cliente`
--
ALTER TABLE `tbl_cliente`
  ADD PRIMARY KEY (`id_cliente`);

--
-- Indices de la tabla `tbl_productos`
--
ALTER TABLE `tbl_productos`
  ADD PRIMARY KEY (`id_productos`);

--
-- Indices de la tabla `tbl_usuario`
--
ALTER TABLE `tbl_usuario`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tbl_cliente`
--
ALTER TABLE `tbl_cliente`
  MODIFY `id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT de la tabla `tbl_productos`
--
ALTER TABLE `tbl_productos`
  MODIFY `id_productos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `tbl_usuario`
--
ALTER TABLE `tbl_usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
